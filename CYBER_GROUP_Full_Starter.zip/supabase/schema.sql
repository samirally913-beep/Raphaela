-- CYBER GROUP: Supabase database starter
-- Run this in Supabase Dashboard > SQL Editor > New query.
-- Review policies before public launch; do not store passwords in your own tables.

create extension if not exists pgcrypto;

-- User profile. Supabase Auth manages credentials; this table stores public profile fields.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  phone text unique,
  display_name text,
  avatar_url text,
  bio text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint username_length check (char_length(username) between 3 and 24)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('direct','group')),
  title text,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member')),
  joined_at timestamptz not null default now(),
  last_read_at timestamptz,
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text,
  message_type text not null default 'text'
    check (message_type in ('text','image','video','audio','document','location','system')),
  media_url text,
  reply_to uuid references public.messages(id) on delete set null,
  created_at timestamptz not null default now(),
  edited_at timestamptz,
  deleted_at timestamptz,
  constraint message_has_content check (
    coalesce(length(trim(body)),0) > 0 or media_url is not null
  )
);

create table if not exists public.location_shares (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  conversation_id uuid references public.conversations(id) on delete cascade,
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  accuracy_m double precision,
  active boolean not null default true,
  expires_at timestamptz not null default (now() + interval '1 hour'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_blocks (
  blocker_id uuid not null references auth.users(id) on delete cascade,
  blocked_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

create table if not exists public.message_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  message_id uuid not null references public.messages(id) on delete cascade,
  reason text not null,
  created_at timestamptz not null default now()
);

create index if not exists messages_conversation_created_idx
  on public.messages(conversation_id, created_at desc);
create index if not exists memberships_user_idx
  on public.conversation_members(user_id);
create index if not exists active_location_expiry_idx
  on public.location_shares(active, expires_at);

-- Enable RLS on all user-facing tables.
alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.location_shares enable row level security;
alter table public.user_blocks enable row level security;
alter table public.message_reports enable row level security;

-- Profiles: authenticated users can read profiles; only edit their own.
drop policy if exists "profiles read authenticated" on public.profiles;
create policy "profiles read authenticated" on public.profiles
  for select to authenticated using (true);
drop policy if exists "profile insert own" on public.profiles;
create policy "profile insert own" on public.profiles
  for insert to authenticated with check (id = auth.uid());
drop policy if exists "profile update own" on public.profiles;
create policy "profile update own" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Conversations are visible to members only.
drop policy if exists "members can read conversations" on public.conversations;
create policy "members can read conversations" on public.conversations
  for select to authenticated using (
    exists (select 1 from public.conversation_members cm
      where cm.conversation_id = id and cm.user_id = auth.uid())
  );
drop policy if exists "signed in can create conversation" on public.conversations;
create policy "signed in can create conversation" on public.conversations
  for insert to authenticated with check (created_by = auth.uid());

-- Membership list visible only to members of the same conversation.
drop policy if exists "conversation members can read membership" on public.conversation_members;
create policy "conversation members can read membership" on public.conversation_members
  for select to authenticated using (
    exists (select 1 from public.conversation_members cm
      where cm.conversation_id = conversation_id and cm.user_id = auth.uid())
  );
-- Users can add themselves as first member; invites/add-member flows should be implemented server-side.
drop policy if exists "user can join self" on public.conversation_members;
create policy "user can join self" on public.conversation_members
  for insert to authenticated with check (user_id = auth.uid());

-- Messages: only members can read/send. Sender must be current user.
drop policy if exists "members can read messages" on public.messages;
create policy "members can read messages" on public.messages
  for select to authenticated using (
    exists (select 1 from public.conversation_members cm
      where cm.conversation_id = conversation_id and cm.user_id = auth.uid())
  );
drop policy if exists "members can send messages" on public.messages;
create policy "members can send messages" on public.messages
  for insert to authenticated with check (
    sender_id = auth.uid() and
    exists (select 1 from public.conversation_members cm
      where cm.conversation_id = conversation_id and cm.user_id = auth.uid())
  );
drop policy if exists "sender can edit own messages" on public.messages;
create policy "sender can edit own messages" on public.messages
  for update to authenticated using (sender_id = auth.uid()) with check (sender_id = auth.uid());

-- Location: share is visible to the owner and members of the chosen conversation.
drop policy if exists "owner or shared group can read location" on public.location_shares;
create policy "owner or shared group can read location" on public.location_shares
  for select to authenticated using (
    user_id = auth.uid() or (
      active = true and expires_at > now() and conversation_id is not null and
      exists (select 1 from public.conversation_members cm
        where cm.conversation_id = location_shares.conversation_id and cm.user_id = auth.uid())
    )
  );
drop policy if exists "owner can create location share" on public.location_shares;
create policy "owner can create location share" on public.location_shares
  for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "owner can update location share" on public.location_shares;
create policy "owner can update location share" on public.location_shares
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Blocking/reporting: a user controls their own block list and reports.
drop policy if exists "read own blocks" on public.user_blocks;
create policy "read own blocks" on public.user_blocks
  for select to authenticated using (blocker_id = auth.uid());
drop policy if exists "create own blocks" on public.user_blocks;
create policy "create own blocks" on public.user_blocks
  for insert to authenticated with check (blocker_id = auth.uid());
drop policy if exists "remove own blocks" on public.user_blocks;
create policy "remove own blocks" on public.user_blocks
  for delete to authenticated using (blocker_id = auth.uid());
drop policy if exists "report own message" on public.message_reports;
create policy "report own message" on public.message_reports
  for insert to authenticated with check (reporter_id = auth.uid());

-- Enable realtime for messages and location updates (if not already present).
do $$
begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
do $$
begin
  alter publication supabase_realtime add table public.location_shares;
exception when duplicate_object then null;
when undefined_object then null;
end $$;

-- IMPORTANT:
-- 1) Do not expose service_role keys in browser code.
-- 2) OTP/SMS delivery requires an Auth provider configured in Supabase.
-- 3) Group creation/member invitations should be done through a secure server/Edge Function,
--    not by letting arbitrary users add themselves to any conversation.
-- 4) Add Storage bucket policies before enabling media uploads.
-- 5) Have the schema reviewed and test RLS policies before production.
