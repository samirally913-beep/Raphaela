CYBER GROUP — WhatsApp-inspired UI prototype

Open index.html in a browser, or host this folder on HTTPS. On Android, open the hosted site in Chrome and use menu > Add to Home screen / Install app if available.

Included:
- WhatsApp-inspired chat list and bottom tabs: Chats, Updates, Communities, Calls.
- Login/Register demo asks for username/mention, phone, password, and DP image.
- Cyber welcome screen with salute animation.
- Demo chat and location permission request.

Important: this is a front-end prototype, not a complete messaging service. Login is not authenticated by a server; messages do not reach other users; DP is held only in browser memory for this session; real groups, OTP, media sharing, voice/video calls, push notifications, and live location shared with others require a secure backend and testing. Do not use real passwords.
